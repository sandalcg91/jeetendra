package com.HQLprogram;

public class TestCustomerSQLHQL {

	public static void main(String[] args)
	{
		
/*		SelectAllRecords.sqlSelectQuery();
		System.out.println("---------------------------------------------------------------------------------");
		SelectAllRecords.hqlSelectQuery();
		System.out.println("---------------------------------------------------------------------------------");
		SelectAllRecords.selectByCriteria();
		System.out.println("---------------------------------------------------------------------------------");
*/		
/*		
		PerticulerField.sqlFieldSelect();
		System.out.println("---------------------------------------------------------------------------------");
		PerticulerField.hqlFieldSelect();
		System.out.println("---------------------------------------------------------------------------------");
		PerticulerField.fieldByCriteria();
		System.out.println("---------------------------------------------------------------------------------");
*/		
/*		
		Like.sqlLikeQuery();
		System.out.println("---------------------------------------------------------------------------------");
		Like.hqlLikeQuery();
		System.out.println("---------------------------------------------------------------------------------");
		Like.LikeQueryByCriteria();
		System.out.println("---------------------------------------------------------------------------------");
*/		
/*		
		OrderByClause.sqlOrderByQuery();
		System.out.println("---------------------------------------------------------------------------------");
		OrderByClause.hqlOrderByQuery();
		System.out.println("---------------------------------------------------------------------------------");
		OrderByClause.OrderByCriteria();
		System.out.println("---------------------------------------------------------------------------------");
*/
/*
		WhereClause.sqlWhereClause();
		System.out.println("---------------------------------------------------------------------------------");
		WhereClause.hqlWhereClause();
		System.out.println("---------------------------------------------------------------------------------");
		WhereClause.whereByCriteria();
		System.out.println("---------------------------------------------------------------------------------");
*/
		
/*		WhereClauseWithAND.sqlWhereClauseAND();
		System.out.println("---------------------------------------------------------------------------------");
		WhereClauseWithAND.hqlWhereClauseAND();
		System.out.println("---------------------------------------------------------------------------------");
		WhereClauseWithAND.whereByCriteriaAND();
		System.out.println("---------------------------------------------------------------------------------");
*/
/*		WhereClauseWithOR.sqlWhereClauseOR();
		System.out.println("---------------------------------------------------------------------------------");
		WhereClauseWithOR.hqlWhereClauseOR();
		System.out.println("---------------------------------------------------------------------------------");
		WhereClauseWithOR.whereByCriteriaOR();
		System.out.println("---------------------------------------------------------------------------------");
*/		
/*		DistinctRecords.sqlSelectDistinct();
		System.out.println("---------------------------------------------------------------------------------");
		DistinctRecords.hqlSelectDistinct();
		System.out.println("---------------------------------------------------------------------------------");	
*/
/*		UpdateQuery.sqlUpdateQuery();
		System.out.println("---------------------------------------------------------------------------------");
		UpdateQuery.hqlUpdateQuery();
		System.out.println("---------------------------------------------------------------------------------");
*/
/*		DeleteQuery.sqlDeleteQuery();
		System.out.println("---------------------------------------------------------------------------------");
		DeleteQuery.hqlDeleteQuery();
		System.out.println("---------------------------------------------------------------------------------");
*/
	}
}