package com.HQLprogram;

public class TestEmpSQLHQL {

	public static void main(String[] args) {
		
/*		GroupByClause.sqlGroupByQuery();
		System.out.println("-------------------------------------------------------------------------------------");
		GroupByClause.hqlGroupByQuery();
		System.out.println("-------------------------------------------------------------------------------------");
		GroupByClause.groupByCriteria();
		System.out.println("-------------------------------------------------------------------------------------");
*/
		Limit_Top.sqlLimitByQuery();
		System.out.println("-------------------------------------------------------------------------------------");
		Limit_Top.hqlLimitQuery();
		System.out.println("-------------------------------------------------------------------------------------");
		
/*		Between.sqlBetween();
		System.out.println("-------------------------------------------------------------------------------------");
		Between.hqlBetween();
		System.out.println("-------------------------------------------------------------------------------------");
		Between.betweenByCriteria();
		System.out.println("-------------------------------------------------------------------------------------");
*/
/*		LessThan.sqlLessThan();
		System.out.println("-------------------------------------------------------------------------------------");
		LessThan.hqlLessThan();
		System.out.println("-------------------------------------------------------------------------------------");
		LessThan.lessThanByCriteria();
		System.out.println("-------------------------------------------------------------------------------------");
*/		
/*		GreaterThan.sqlGreaterThan();
		System.out.println("-------------------------------------------------------------------------------------");
		GreaterThan.hqlGreaterThan();
		System.out.println("-------------------------------------------------------------------------------------");
		GreaterThan.greaterThanByCriteria();
		System.out.println("-------------------------------------------------------------------------------------");
*/
		
/*		INClause.sqlIn();
		System.out.println("-------------------------------------------------------------------------------------");
		INClause.hqlIn();
		System.out.println("-------------------------------------------------------------------------------------");
		INClause.inQueryByCriteria();
		System.out.println("-------------------------------------------------------------------------------------");
*/
	}
}